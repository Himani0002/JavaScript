

document.getElementById("myImg").src = "cute1.jpg";

document.getElementById("Heading1").innerHTML = "Doja Cat";
document.getElementById("Heading2").innerHTML = "She is GOOd girl";
